--Inscriber Mizumoji
function c915234232.initial_effect(c)

end
asdfas 